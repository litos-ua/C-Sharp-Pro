﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace WebApplicationNotes.Migrations
{
    /// <inheritdoc />
    public partial class InitialDbAndTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    AlternatePhone = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Notes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Content = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Tags = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    ContactId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Notes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Notes_Contacts_ContactId",
                        column: x => x.ContactId,
                        principalTable: "Contacts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Contacts",
                columns: new[] { "Id", "AlternatePhone", "Description", "Email", "Name", "Phone" },
                values: new object[,]
                {
                    { 1, "+64 27 765 4321", "Business consultant specializing in project management.", "andrew.kulbicky@google.com", "Andrew Kulbicky", "+64 21 123 4567" },
                    { 2, "+64 27 543 2198", "Freelance web developer with a focus on JavaScript frameworks.", "nathan.greenberg@unisoft.nz", "Nathan Greenberg", "+64 22 987 6543" },
                    { 3, "+64 29 314 5792", "Graphic designer passionate about branding and UX design.", "barbara.tonelli@yahoo.com", "Barbara Tonelli", "+64 20 135 7913" },
                    { 4, "+64 28 234 5678", "Event planner specializing in corporate and private events.", "irena.hopkins@private.nz", "Irena Hopkins", "+64 21 467 8293" },
                    { 5, "+64 24 765 4321", "Content writer with expertise in SEO and digital marketing.", "karolina.jurkova@google.com", "Karolina Jurkova", "+64 25 987 6543" },
                    { 6, "+64 26 541 9334", "Computer engineer specializing in server computing solutions.", "rebecca.goldsmith@computer-force.nz", "Rebecca GoldSmith", "+64 73 292 7774" },
                    { 7, "+64 24 755 7274", "Software engineer specializing in .net solutions.", "ivona.andersen@sharp.nz", "Ivona Andersen", "+64 24 143 2274" },
                    { 8, "+64 26 384 9274", "Computer engineer specializing in server computing solutions.", "alexander.johansen@example.com", "Alexander Johansen", "+64 23 192 8374" }
                });

            migrationBuilder.InsertData(
                table: "Notes",
                columns: new[] { "Id", "ContactId", "Content", "CreatedAt", "Tags", "Title" },
                values: new object[,]
                {
                    { 1, 1, "Prepare documents for kickoff meeting.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(7957), "meeting,project", "Project Kickoff" },
                    { 2, 1, "Review project budget for Q1.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9233), "budget,finance", "Budget Review" },
                    { 3, 1, "Consolidate feedback from client meeting.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9240), "feedback,client", "Client Feedback" },
                    { 4, 2, "Prepare materials for React training session.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9242), "training,react", "React Training" },
                    { 5, 2, "Update portfolio with recent projects.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9244), "portfolio,update", "Portfolio Update" },
                    { 6, 2, "Document API integration process.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9246), "API,documentation", "API Integration" },
                    { 7, 3, "Present logo redesign concepts.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9247), "logo,design", "Logo Redesign" },
                    { 8, 3, "Conduct UX audit for e-commerce client.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9249), "audit,UX", "UX Audit" },
                    { 9, 3, "Draft updated brand guidelines.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9251), "brand,guidelines", "Brand Guidelines" },
                    { 10, 4, "Finalize itinerary for corporate retreat.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9253), "event,itinerary", "Event Itinerary" },
                    { 11, 4, "Compile list of vendors for event.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9255), "vendors,event", "Vendor List" },
                    { 12, 4, "Visit shortlisted venues for event.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9257), "venue,scouting", "Venue Scouting" },
                    { 13, 5, "Complete SEO audit for blog.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9259), "SEO,audit", "SEO Audit" },
                    { 14, 5, "Draft content calendar for social media.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9261), "content,calendar", "Content Calendar" },
                    { 15, 5, "Write ad copy for campaign.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9263), "ad,copywriting", "Ad Copywriting" },
                    { 16, 8, "Plan migration to cloud infrastructure.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9265), "cloud,migration", "Cloud Migration" },
                    { 17, 8, "Perform code review for team project.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9266), "code,review", "Code Review" },
                    { 18, 8, "Draft DevOps strategy document.", new DateTime(2024, 12, 10, 11, 54, 30, 702, DateTimeKind.Utc).AddTicks(9268), "DevOps,strategy", "DevOps Strategy" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Notes_ContactId",
                table: "Notes",
                column: "ContactId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Notes");

            migrationBuilder.DropTable(
                name: "Contacts");
        }
    }
}
